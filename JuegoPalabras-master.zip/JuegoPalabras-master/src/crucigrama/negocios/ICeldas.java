/*
 * Creado por Pedro Abarca
 * Noviembre,  2015
 * Universidad Técnica Nacional
 */

package crucigrama.negocios;

public interface ICeldas {
    public int getContenido();

    public int getIndexUsuario();
}

