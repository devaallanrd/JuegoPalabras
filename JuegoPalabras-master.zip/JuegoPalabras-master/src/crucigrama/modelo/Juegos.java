/*
 * Creado por Pedro Abarca
 * Noviembre,  2015
 * Universidad Técnica Nacional
 */
package crucigrama.modelo;

/**
 *
 * @author aallanrd
 */
public class Juegos {
    
}
