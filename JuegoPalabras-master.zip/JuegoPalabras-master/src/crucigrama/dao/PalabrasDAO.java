
package crucigrama.dao;

/*
 * Creado por Pedro Abarca
 * Noviembre,  2015
 * Universidad Técnica Nacional
 */

public class PalabrasDAO {
    
}
